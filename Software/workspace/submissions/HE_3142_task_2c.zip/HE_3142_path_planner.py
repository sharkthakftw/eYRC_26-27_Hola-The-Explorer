#!/usr/bin/env python3
# Copyright (c) 2026 e-Yantra, IIT Bombay. All rights reserved.
# These simulation files and source code are the intellectual property of e-Yantra,
# IIT Bombay, provided solely for eYRC 2026-27 (Theme: Hola The Explorer).
# Sharing or redistribution of this material, in whole or in part, is not permitted.

'''
*****************************************************************************************
*
*        =============================================
*           Hola The Explorer (HE) Theme (eYRC 2026-27)
*        =============================================
*
*  This script is to implement Task 2C of Hola The Explorer (HE) Theme (eYRC 2026-27).
*
*****************************************************************************************
'''

# Team ID:          [ 3142 ]
# Author List:      [ Sarthak Gupta, Shourya Gupta ]
# Filename:         path_planner.py
# Functions:        [ footprint, heuristic, simultaneous_segment_distance ]
# Global variables: [ Add every extra global variable you declare to this list ]


############################ WHAT YOU HAVE TO DO ##############################
#
#  r1, r2 and r3 must each reach their goal without touching an obstacle or
#  each other. A wall with ONE gap crosses the arena and the goals cross
#  sides, so the robots must take the gap one at a time. This node plans all
#  three ONCE and publishes each on /rN/plan; path_follower.py drives them.
#
#    camera frame --frame_to_occupancy()--> grid       (given)
#                 --remove_drivable()-----> grid       (from Task 2B)
#                 --planning_grid()-------> blocked    (given)
#                 --plan_all()------------> plans      (YOURS)
#                 --to_path_msg()---------> /rN/plan   (from Task 2B)
#
#  A plan is [(t, x, y), ...]: be at (x, y) t seconds after setting off. All
#  three share one start time, so the TIMES are what keep the robots apart.
#
#  Frame (/rN/odom): origin at the arena's TOP-LEFT corner, x right, y DOWN.
#
#  Run:  ros2 launch hb_description task2c.launch.py
#        ros2 run task_2c path_planner
#        ros2 run task_2c path_follower
#
###############################################################################

import math

import cv2
import numpy as np
import rclpy
from rclpy.duration import Duration
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry, Path

################# ADD EXTRA IMPORTS / GLOBALS HERE ############
import heapq
###############################################################


# ----------------------------------------------------- arena (given, do not edit)
ROBOTS = ("r1", "r2", "r3")          # also the planning order
START_CIRCLES = [(0.8969, 2.2616), (1.2192, 2.2616), (1.5415, 2.2616)]
GOALS = {"r1": (1.9992, 0.7992),     # the goals cross sides
         "r2": (1.2192, 0.5392),
         "r3": (0.4392, 0.7992)}
ARENA_SIZE = 2.4384                  # m
ROBOT_RADIUS = 0.084                 # m
SAFETY_MARGIN = 0.030                # m, kept clear on top of the robot radius

# ----------------------------------------------------- camera (given)
CAMERA_URL = "http://127.0.0.1:8080/stream"
ARENA_LEFT, ARENA_TOP, ARENA_PIXELS = 304, 24, 671       # floor square in the image
GRID_CELLS = 244                     # occupancy grid is GRID_CELLS x GRID_CELLS
CELL_SIZE = ARENA_SIZE / GRID_CELLS  # m, about 1 cm
SAND_LOW, SAND_HIGH = (10, 40, 170), (30, 120, 255)      # sand colour, HSV

# ----------------------------------------------------- planning (tunable)
PLAN_CELL = 0.04                     # m, planning grid cell
PLAN_SPEED = 0.24                    # m/s, the speed the paths are timed at
ROBOT_CLEARANCE = 0.30              # m, keep two robots' plans this far apart
START_DELAY = 2.0                    # s, from publishing to setting off

LATCHED = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL)


######################### OCCUPANCY GRID ######################

def read_frame(url=CAMERA_URL):
    """Given. One BGR frame from the overhead camera."""
    cap = cv2.VideoCapture(url)
    ok, frame = cap.read()
    cap.release()
    if not ok:
        raise RuntimeError("no frame from %s -- is task2c.launch.py running?" % url)
    return frame


def crop_arena(frame):
    """Given. The arena floor only, ARENA_PIXELS square."""
    return frame[ARENA_TOP:ARENA_TOP + ARENA_PIXELS, ARENA_LEFT:ARENA_LEFT + ARENA_PIXELS]


def frame_to_occupancy(frame):
    """Given. Frame -> grid[row, col] = grid[y, x], True = obstacle.
    Only sand is free. To view: cv2.imshow("g", np.where(grid, 0, 255).astype(np.uint8))"""
    hsv = cv2.cvtColor(cv2.medianBlur(crop_arena(frame), 5), cv2.COLOR_BGR2HSV)
    obstacles = cv2.bitwise_not(cv2.inRange(hsv, SAND_LOW, SAND_HIGH))
    # drop specks and thin painted lines, then fill the holes inside each obstacle
    obstacles = cv2.morphologyEx(obstacles, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    contours, _ = cv2.findContours(obstacles, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(obstacles, contours, -1, 255, cv2.FILLED)
    # one pixel per cell; a cell is an obstacle if any part of it is
    small = cv2.resize(obstacles, (GRID_CELLS, GRID_CELLS), interpolation=cv2.INTER_AREA)
    return small > 0


def clear_circle(occupied, xy, radius):
    """Given. Free every cell within `radius` m of point xy (in place)."""
    rows, cols = np.indices(occupied.shape)
    x, y = (cols + 0.5) * CELL_SIZE, (rows + 0.5) * CELL_SIZE
    occupied[(x - xy[0]) ** 2 + (y - xy[1]) ** 2 <= radius ** 2] = False


def remove_drivable(frame, occupied, robots, goals):
    """Free what a robot may drive over; return the grid.

    frame_to_occupancy() marks everything that is not sand as an obstacle --
    including the painted floor, the robots and the goal dots, which leaves
    NO path. Keep the wall and pillars (and each pad's payload)."""
    # free the painted floor
    # the obstacles have low saturation
    cropped = crop_arena(frame)
    hsv = cv2.cvtColor(cropped, cv2.COLOR_BGR2HSV)
    saturation = cv2.split(hsv)[1]
    painted_mask = saturation > 30

    painted = painted_mask.astype(np.uint8)
    frac = cv2.resize(painted.astype(np.float32), (GRID_CELLS, GRID_CELLS), interpolation=cv2.INTER_AREA)
    occupied[frac > 0.65] = False

    # remove lines and specks
    occupied = cv2.morphologyEx(occupied.astype(np.uint8), cv2.MORPH_OPEN, np.ones((2, 2), np.uint8)).astype(bool)

    for xy in START_CIRCLES:
        clear_circle(occupied, xy, ROBOT_RADIUS + 0.02)
    for xy in robots:
        clear_circle(occupied, xy, ROBOT_RADIUS + 0.02)
    for xy in goals:
        clear_circle(occupied, xy, ROBOT_RADIUS + 0.02)

    return occupied
    ##################################################


######################### PLANNING GRID #######################

def planning_grid(occupied):
    """Given. Grid -> blocked[i, j] = blocked[x, y] (NOTE: x first) of PLAN_CELL
    cells. Obstacles grow by ROBOT_RADIUS + SAFETY_MARGIN, so plan the robot's
    centre as a point. The arena's edge is a wall."""
    pad = ROBOT_RADIUS + SAFETY_MARGIN
    k = int(math.ceil(pad / CELL_SIZE))
    disc = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * k + 1, 2 * k + 1))
    inflated = cv2.dilate(occupied.astype(np.uint8), disc) > 0

    # a planning cell is blocked if the robot's centre, standing on the cell's
    # centre, would be too close to an obstacle
    n = int(round(ARENA_SIZE / PLAN_CELL))
    centre = (np.arange(n) + 0.5) * PLAN_CELL
    fine = np.minimum((centre / CELL_SIZE).astype(int), GRID_CELLS - 1)
    blocked = inflated[np.ix_(fine, fine)].T        # [row=y, col=x] -> [i=x, j=y]
    near_wall = (centre < pad) | (centre > ARENA_SIZE - pad)
    blocked[near_wall, :] = True
    blocked[:, near_wall] = True
    return blocked


def to_cell(p):
    """Given. Point (x, y) in m -> planning cell (i, j)."""
    n = int(round(ARENA_SIZE / PLAN_CELL))
    return (min(max(int(p[0] / PLAN_CELL), 0), n - 1), min(max(int(p[1] / PLAN_CELL), 0), n - 1))


def to_world(c):
    """Given. Planning cell (i, j) -> its centre (x, y) in m."""
    return ((c[0] + 0.5) * PLAN_CELL, (c[1] + 0.5) * PLAN_CELL)


def nearest_free(blocked, p, max_r=0.30):
    """Given. The free cell closest to point p, or None within max_r m."""
    c = to_cell(p)
    if not blocked[c]:
        return c
    free = [(i, j) for i in range(blocked.shape[0]) for j in range(blocked.shape[1])
            if not blocked[i, j] and abs(i - c[0]) * PLAN_CELL <= max_r
            and abs(j - c[1]) * PLAN_CELL <= max_r]
    return min(free, key=lambda q: math.dist(to_world(q), p)) if free else None


def plan_all(blocked, starts):
    # Search in discrete time so a robot can wait for a reserved area to clear.
    step_time = PLAN_CELL / PLAN_SPEED
    max_steps = 600

    # Reserve a safety-radius footprint around each planned robot position.
    cell_radius = int(math.ceil(ROBOT_CLEARANCE / PLAN_CELL))
    offsets = [
        (di, dj)
        for di in range(-cell_radius, cell_radius + 1)
        for dj in range(-cell_radius, cell_radius + 1)
        if math.hypot(di * PLAN_CELL, dj * PLAN_CELL) <= ROBOT_CLEARANCE
    ]

    def simultaneous_segment_distance(a0, a1, b0, b1):
        """Closest separation while both robots traverse one time interval."""
        a0 = np.asarray(to_world(a0), dtype=float)
        a1 = np.asarray(to_world(a1), dtype=float)
        b0 = np.asarray(to_world(b0), dtype=float)
        b1 = np.asarray(to_world(b1), dtype=float)

        relative_start = a0 - b0
        relative_motion = (a1 - a0) - (b1 - b0)
        motion_squared = float(np.dot(relative_motion, relative_motion))

        if motion_squared == 0.0:
            return float(np.linalg.norm(relative_start))

        # Find the point in the interval where relative positions are closest.
        fraction = np.clip(
            -float(np.dot(relative_start, relative_motion)) / motion_squared,
            0.0,
            1.0,
        )
        closest = relative_start + fraction * relative_motion
        return float(np.linalg.norm(closest))

    def footprint(cell):
        cells = set()
        for di, dj in offsets:
            i = cell[0] + di
            j = cell[1] + dj
            if 0 <= i < blocked.shape[0] and 0 <= j < blocked.shape[1]:
                cells.add((i, j))
        return cells

    # Later robots avoid earlier robots' positions and movements at each step.
    reserved_cells = [set() for _ in range(max_steps + 1)]
    reserved_edges = [[] for _ in range(max_steps)]
    plans = {}

    for robot in ROBOTS:
        start = starts[robot]
        goal = GOALS[robot]
        start_cell = nearest_free(blocked, start)
        goal_cell = to_cell(goal)

        if start_cell is None or blocked[goal_cell]:
            return None
        if start_cell in reserved_cells[0]:
            return None

        def heuristic(cell):
            return abs(cell[0] - goal_cell[0]) + abs(cell[1] - goal_cell[1])

        start_state = (start_cell, 0)
        frontier = [(heuristic(start_cell), 0, start_state)]
        came_from = {start_state: None}
        final_state = None

        while frontier:
            _, _, state = heapq.heappop(frontier)
            cell, time_step = state

            if cell == goal_cell:
                final_state = state
                break

            if time_step >= max_steps:
                continue

            next_time = time_step + 1
            i, j = cell
            neighbours = (
                (i, j),  # Staying in place lets the robot wait for a reservation.
                (i - 1, j),
                (i + 1, j),
                (i, j - 1),
                (i, j + 1),
            )

            for next_cell in neighbours:
                ni, nj = next_cell
                if not (0 <= ni < blocked.shape[0] and 0 <= nj < blocked.shape[1]):
                    continue
                if blocked[next_cell]:
                    continue
                if next_cell in reserved_cells[next_time]:
                    continue
                # Check the whole move interval, not just its two endpoints.
                too_close = any(
                    simultaneous_segment_distance(
                        cell, next_cell, other_start, other_end
                    ) < ROBOT_CLEARANCE
                    for other_start, other_end in reserved_edges[time_step]
                )
                if too_close:
                    continue

                next_state = (next_cell, next_time)

                # Skip states already discovered; add new states to the search.
                if next_state in came_from:
                    continue

                came_from[next_state] = state
                priority = next_time + heuristic(next_cell)
                heapq.heappush(
                    frontier,
                    (priority, next_time, next_state),
                )

        if final_state is None:
            return None

        route = []
        state = final_state
        while state is not None:
            route.append(state[0])
            state = came_from[state]
        route.reverse()

        timed_plan = [(0.0, start[0], start[1])]

        for index, cell in enumerate(route[1:], start=1):
            x, y = to_world(cell)
            timed_plan.append((index * step_time, x, y))

        last_time = (len(route) - 1) * step_time
        last_x, last_y = to_world(route[-1])
        goal_time = last_time + math.dist((last_x, last_y), goal) / PLAN_SPEED
        timed_plan.append((goal_time, goal[0], goal[1]))
        plans[robot] = timed_plan

        # Reserve the robot's footprint and movement; keep its goal reserved after arrival.
        for time_step in range(max_steps + 1):
            route_index = min(time_step, len(route) - 1)
            cell = route[route_index]
            reserved_cells[time_step].update(footprint(cell))

            if time_step < max_steps:
                next_index = min(time_step + 1, len(route) - 1)
                next_cell = route[next_index]
                reserved_edges[time_step].append((cell, next_cell))

    return plans

    ##################################################


######################### NODE ################################

class PathPlanner(Node):
    """Given, except to_path_msg(). Waits for every /rN/odom, plans once, and
    publishes each path on /rN/plan (latched) with one shared start time."""

    def __init__(self):
        super().__init__("task_2c_path_planner")
        self.pose, self.pubs = {}, {}
        for r in ROBOTS:
            self.create_subscription(Odometry, f"/{r}/odom", self._odom_cb(r), 10)
            self.pubs[r] = self.create_publisher(Path, f"/{r}/plan", LATCHED)
        self.planned = False
        self.create_timer(0.2, self.tick)
        self.get_logger().info("task 2C planner: goals %s" % GOALS)

    def _odom_cb(self, robot):
        def cb(msg):
            p = msg.pose.pose.position
            self.pose[robot] = (p.x, p.y)
        return cb

    def to_path_msg(self, plan, start):
        """[(t, x, y), ...] and start (rclpy Time) -> nav_msgs/Path."""
        # from Task 2B
        path = Path()
        path.header.frame_id = "odom"
        path.header.stamp = start.to_msg()

        for t, x, y in plan:
            ps = PoseStamped()
            ps.header.frame_id = "odom"
            ps.header.stamp = (start + Duration(seconds = t)).to_msg()

            ps.pose.position.x = x
            ps.pose.position.y = y

            path.poses.append(ps)
        return path

    def tick(self):
        if self.planned or len(self.pose) < len(ROBOTS):
            return                              # wait for every robot's odom
        self.planned = True

        frame = read_frame()
        occupied = remove_drivable(frame, frame_to_occupancy(frame),
                                   robots=list(self.pose.values()), goals=list(GOALS.values()))
        blocked = planning_grid(occupied)
        self.get_logger().info("occupancy grid: %.1f%% obstacle; planning grid %d x %d"
                               % (100.0 * occupied.mean(), *blocked.shape))

        plans = plan_all(blocked, self.pose)
        if plans is None:
            self.get_logger().error("no conflict-free joint plan. Starts and goals, as the planner saw them:")
            for r in ROBOTS:
                self.get_logger().error("  %s start %s %s -> goal %s %s" % (
                    r, self.pose[r], "BLOCKED" if blocked[to_cell(self.pose[r])] else "free",
                    GOALS[r], "BLOCKED" if blocked[to_cell(GOALS[r])] else "free"))
            return

        start = self.get_clock().now() + Duration(seconds=START_DELAY)   # shared by all three
        for r in ROBOTS:
            self.pubs[r].publish(self.to_path_msg(plans[r], start))
            length = sum(math.dist(a[1:], b[1:]) for a, b in zip(plans[r], plans[r][1:]))
            self.get_logger().info("%s: published /%s/plan, %d poses, %.2f m, arrives at t=%.1f s"
                                   % (r, r, len(plans[r]), length, plans[r][-1][0]))


def main():
    rclpy.init()
    node = PathPlanner()
    try:
        rclpy.spin(node)                        # keeps the latched paths available
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
